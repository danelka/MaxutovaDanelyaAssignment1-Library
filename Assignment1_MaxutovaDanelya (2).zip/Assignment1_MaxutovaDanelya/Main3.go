package main

import (
	"fmt"
	"github.com/danelka/MaxutovaDanelyaAssignment1-Library/Employee"
)

func main() {
	// Создаем экземпляр компании
	company := Employee.NewCompany()

	// Добавляем сотрудников
	company.AddEmployee(Employee.FullTimeEmployee{
		ID:     1,
		Name:   "Bob",
		Salary: 50000,
	})

	company.AddEmployee(Employee.PartTimeEmployee{
		ID:          2,
		Name:        "ALICE",
		HourlyRate:  40,
		HoursWorked: 100,
	})

	// Отображаем всех сотрудников
	company.ListEmployees()
}
