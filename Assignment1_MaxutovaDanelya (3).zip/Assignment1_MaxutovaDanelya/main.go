package main

import (
	"fmt"
	"github.com/danelka/MaxutovaDanelyaAssignment1-Library/Library"
)

func main() {
	lib := Library.NewLibrary()

	err := lib.AddBook(Library.Book{ID: "1", Title: "Book A", Author: "Author A", IsBorrowed: false})
	if err != nil {
		fmt.Println("Error:", err)
	}

	err = lib.AddBook(Library.Book{ID: "1", Title: "Book B", Author: "Author B", IsBorrowed: false})
	if err != nil {
		fmt.Println("Error:", err)
	}

	lib.ListBooks()
}
