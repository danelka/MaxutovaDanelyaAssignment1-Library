package Library

import (
	"errors"
	"fmt"
)

type Book struct {
	ID         string
	Title      string
	Author     string
	IsBorrowed bool
}

type Library struct {
	Books []Book
}

func NewLibrary() *Library {
	return &Library{Books: []Book{}}
}

func (l *Library) AddBook(book Book) error {
	// Проверяем, существует ли книга с таким ID
	for _, existingBook := range l.Books {
		if existingBook.ID == book.ID {
			return errors.New("book with this ID already exists") // Ошибка, если книга с таким ID уже есть
		}
	}

	// Если книги с таким ID нет, добавляем её
	l.Books = append(l.Books, book)
	fmt.Println("Book added successfully.")
	return nil
}

func (l *Library) BorrowBook(id string) {
	for i, book := range l.Books {
		if book.ID == id {
			if book.IsBorrowed {
				fmt.Println("Book is already borrowed.")
				return
			}
			// Изменение состояния книги
			l.Books[i].IsBorrowed = true
			fmt.Println("Book borrowed successfully.")
			return
		}
	}
	fmt.Println("Book not found.")
}

func (l *Library) ReturnBook(id string) {
	for i, book := range l.Books {
		if book.ID == id {
			if !book.IsBorrowed {
				fmt.Println("Book is not borrowed.")
				return
			}
			// Возвращение книги
			l.Books[i].IsBorrowed = false
			fmt.Println("Book returned successfully.")
			return
		}
	}
	fmt.Println("Book not found.")
}

func (l *Library) ListBooks() {
	if len(l.Books) == 0 {
		fmt.Println("No books available.")
		return
	}
	for _, book := range l.Books {
		if !book.IsBorrowed {
			fmt.Printf("ID: %s, Title: %s, Author: %s\n", book.ID, book.Title, book.Author)
		}
	}
}
