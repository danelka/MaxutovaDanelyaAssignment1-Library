package main

import (
	"fmt"
	"github.com/danelka/MaxutovaDanelyaAssignment1-Library/Employee"
)

func main() {
	c := Employee.NewCompany()

	for {
		fmt.Println("\nEmployee Management System")
		fmt.Println("1. Add FullTime Employee")
		fmt.Println("2. Add PartTime Employee")
		fmt.Println("3. List Employees")
		fmt.Println("4. Remove Employee")
		fmt.Println("5. Exit")
		fmt.Print("Enter your choice: ")

		var choice int
		fmt.Scan(&choice)

		switch choice {
		case 1:
			emp := Employee.ParseFullTimeEmployee()
			c.AddEmployee(emp)
		case 2:
			emp := Employee.ParsePartTimeEmployee()
			c.AddEmployee(emp)
		case 3:
			c.ListEmployees()
		case 4:
			fmt.Print("Enter Employee ID to remove: ")
			var id uint64
			fmt.Scan(&id)
			c.RemoveEmployee(id)
		case 5:
			fmt.Println("Exiting...")
			return
		default:
			fmt.Println("Invalid choice. Please try again.")
		}
	}
}
